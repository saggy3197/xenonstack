package com.gym.phoenixgym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoenixGymApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhoenixGymApplication.class, args);
	}

}
